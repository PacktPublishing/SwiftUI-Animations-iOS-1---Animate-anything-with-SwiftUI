//
//  Light_SwitchApp.swift
//  Light Switch
//
//  Created by Stephen DeStefano on 1/4/21.
//

import SwiftUI

@main
struct Light_SwitchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
