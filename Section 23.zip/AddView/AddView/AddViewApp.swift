//
//  AddViewApp.swift
//  AddView
//
//  Created by Stephen DeStefano on 1/2/21.
//

import SwiftUI

@main
struct AddViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
