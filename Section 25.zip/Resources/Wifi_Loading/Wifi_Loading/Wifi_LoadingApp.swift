//
//  Wifi_LoadingApp.swift
//  Wifi_Loading
//
//  Created by Stephen DeStefano on 1/8/21.
//

import SwiftUI

@main
struct Wifi_LoadingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
